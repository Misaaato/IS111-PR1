﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] Mas = { 65, 30, 2, 6, 17, 83, 99, 8, 12, 91 };
            Array.Sort(Mas);
            foreach (int i in Mas)
            {
                Console.Write(i + " ");
            }
            Console.ReadLine();
        }
    }
}
