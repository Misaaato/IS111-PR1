﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int rows = Convert.ToInt32(Console.ReadLine()); // количество строк пирамиды
            int num = 1; // начальное число


            for (int i = 1; i <= rows; i++)
            {
                for (int l = rows; l >= i; l--)
                {
                    Console.Write(" ");
                }
                for (int j = 1; j <= i; j++)
                {

                    Console.Write(num + " ");
                    num++;
                }

                Console.WriteLine();
            }

            Console.ReadLine();
        }
    }
}
