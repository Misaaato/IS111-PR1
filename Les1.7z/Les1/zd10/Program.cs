﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int number = Convert.ToInt32(Console.ReadLine());
            int index = Convert.ToInt32(Console.ReadLine());

            int result = FindNthDigit(number, index);
            Console.WriteLine("{0} = индекс, {1} = число", index, result);
            Console.ReadLine();
        }

        static int FindNthDigit(int number, int index)
        {
            int count = 0;
            while (number != 0)
            {
                int digit = number % 10;
                count++;
                if (count == index)
                {
                    return digit;
                }
                number = number / 10;
            }
            return -1;
        }
    }
}
