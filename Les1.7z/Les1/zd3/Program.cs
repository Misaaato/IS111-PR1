﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            int num = 1;

            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(num + " ");
                    num++;
                    if (num > n)
                    {
                        break;
                        Console.WriteLine(Convert.ToString(num));
                    }
                }
                if (num > n)
                {
                    break;
                }
                Console.WriteLine();
            }
            string stop = Console.ReadLine();
        }
    }
}
