﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Les1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter n");
            int n = Convert.ToInt32(Console.ReadLine());
            int i; for (i = 1; i <= n; i++)
            {
                Console.Write(i + " ");
                if (i % 10 == 0) Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
