﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите день:");
            int day = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите месяц:");
            int month = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Введите год:");
            int year = Convert.ToInt32(Console.ReadLine());

            bool isDateCorrect = CheckDate(day, month, year);
            if (isDateCorrect)
            {
                Console.WriteLine("Такая дата существует");
            }
            else
            {
                Console.WriteLine("Такой даты не существует");
            }
            Console.ReadLine();
        }
        static bool CheckDate(int day, int month, int year)
        {
            if (month < 1 || month > 12 || year < 1)
                return false;
            if (day < 1 || day > 31)
                return false;
            if (month == 2 && day > 28)
                return false;
            if ((month == 4 || month == 6 || month == 9 || month == 11) && day > 30)
                return false;
            return true;
        }
    }
}
