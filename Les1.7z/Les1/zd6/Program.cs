﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zd6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            int l = Convert.ToInt32(Console.ReadLine());

            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= n; j++)
                {
                    for (char k = 'a'; k < 'a' + l; k++)
                    {
                        for (char m = 'a'; m < 'a' + l; m++)
                        {
                            if (m > i && m > j)
                            {
                                Console.WriteLine($"{i}{j}{k}{m}{i + 1}");
                            }
                        }
                    }
                }
            }
            Console.ReadLine();
        }
    }
}
